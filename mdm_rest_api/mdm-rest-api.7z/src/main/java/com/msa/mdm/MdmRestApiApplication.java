package com.msa.mdm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MdmRestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MdmRestApiApplication.class, args);
	}
}
