package com.msa.mdm.dao;

import java.util.List;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

import com.msa.mdm.entity.ProductData;

public interface ProductDataDao  extends ElasticsearchRepository < ProductData, Long > {
    public List< ProductData >  findByItemDescription(String name);


}
